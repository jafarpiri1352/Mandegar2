plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.mandegar.two"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.mandegar.two"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.2.2"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
}
