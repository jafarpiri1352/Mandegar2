package ir.mandegar.two

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Local encrypted storage helper. AES-256-GCM key is generated and held by Android Keystore.
 * The key is non-exportable; encrypted data is stored in app-private SharedPreferences.
 */
class SecureStore(private val context: android.content.Context) {
    private val prefs = context.getSharedPreferences("mandegar_private_v1", 0)
    private val alias = "mandegar2_aes_key"

    private fun getKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey(alias, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun saveNote(note: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getKey())
        val encrypted = cipher.doFinal(note.toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        prefs.edit().putString("note", Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
    }

    fun readNote(): String {
        val packedString = prefs.getString("note", null) ?: return ""
        return try {
            val packed = Base64.decode(packedString, Base64.NO_WRAP)
            val iv = packed.copyOfRange(0, 12)
            val ciphertext = packed.copyOfRange(12, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }

    fun deleteNote() {
        prefs.edit().remove("note").apply()
    }

    // Conversation history is encrypted separately with the same Keystore-protected AES-GCM key.
    fun saveChat(history: String) {
        saveEncrypted("chat_history", history)
    }

    fun readChat(): String {
        return readEncrypted("chat_history")
    }

    fun deleteChat() {
        prefs.edit().remove("chat_history").apply()
    }


    fun saveAiConfig(endpoint: String, model: String, apiKey: String) {
        saveEncrypted("ai_endpoint", endpoint)
        saveEncrypted("ai_model", model)
        saveEncrypted("ai_key", apiKey)
    }

    fun readAiEndpoint(): String = readEncrypted("ai_endpoint")
    fun readAiModel(): String = readEncrypted("ai_model")
    fun readAiKey(): String = readEncrypted("ai_key")

    fun clearAiKey() {
        prefs.edit().remove("ai_key").apply()
    }

    private fun saveEncrypted(storageKey: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        prefs.edit().putString(storageKey, Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)).apply()
    }

    private fun readEncrypted(storageKey: String): String {
        val packedString = prefs.getString(storageKey, null) ?: return ""
        return try {
            val packed = Base64.decode(packedString, Base64.NO_WRAP)
            val iv = packed.copyOfRange(0, 12)
            val ciphertext = packed.copyOfRange(12, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }
}
